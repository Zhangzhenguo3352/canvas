Due to copyright restrictions, you need to put your own video file in this directory, and reference it in example.html for this example to work.
